import { useState, useEffect, useRef, useCallback } from 'react';

interface MagicParticle {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  life: number;
  hue: number;
  type: 'star' | 'sparkle' | 'flower' | 'heart' | 'firefly';
}

interface Creature {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  type: 'butterfly' | 'bird' | 'fish' | 'rabbit' | 'cat';
  color: string;
  size: number;
  life: number;
}

interface Drawing {
  id: number;
  points: { x: number; y: number }[];
  color: string;
  size: number;
}

const creaturesEmojis = {
  butterfly: ['🦋', '🐝', '🦅', '🐦'],
  bird: ['🐦', '🦆', '🦉', '🐧'],
  fish: ['🐠', '🐟', '🐡', '🦈'],
  rabbit: ['🐰', '🐇', '🦊', '🦝'],
  cat: ['🐱', '🐈', '🐯', '🦁'],
};

const magicColors = [
  '#FF6B6B', '#4ECDC4', '#A855F7', '#F472B6', '#34D399', 
  '#60A5FA', '#FBBF24', '#F97316', '#EC4899', '#8B5CF6',
];

export default function App() {
  const [particles, setParticles] = useState<MagicParticle[]>([]);
  const [creatures, setCreatures] = useState<Creature[]>([]);
  const [drawings, setDrawings] = useState<Drawing[]>([]);
  const [currentPath, setCurrentPath] = useState<{ x: number; y: number }[]>([]);
  const [selectedTool, setSelectedTool] = useState<'draw' | 'creature' | 'magic' | 'erase'>('magic');
  const [selectedColor, setSelectedColor] = useState('#A855F7');
  const [brushSize] = useState(20);
  const [isDrawing, setIsDrawing] = useState(false);
  const [score, setScore] = useState(0);
  const [showHint, setShowHint] = useState(true);
  const [timeOfDay, setTimeOfDay] = useState<'dawn' | 'day' | 'dusk' | 'night'>('night');
  const [stars, setStars] = useState<{ x: number; y: number; size: number; twinkle: number }[]>([]);
  
  const canvasRef = useRef<HTMLDivElement>(null);
  const lastCreatureTime = useRef(0);

  useEffect(() => {
    // Generate background stars
    const newStars = Array.from({ length: 60 }, () => ({
      x: Math.random() * 100,
      y: Math.random() * 60,
      size: Math.random() * 2 + 1,
      twinkle: Math.random(),
    }));
    setStars(newStars);

    // Cycle time of day
    const interval = setInterval(() => {
      setTimeOfDay(t => {
        const times: ('dawn' | 'day' | 'dusk' | 'night')[] = ['dawn', 'day', 'dusk', 'night'];
        const currentIndex = times.indexOf(t);
        return times[(currentIndex + 1) % 4];
      });
    }, 15000);
    return () => clearInterval(interval);
  }, []);

  const getBackground = () => {
    switch (timeOfDay) {
      case 'dawn': return 'bg-gradient-to-b from-pink-300 via-orange-200 to-yellow-100';
      case 'day': return 'bg-gradient-to-b from-blue-400 via-cyan-200 to-sky-100';
      case 'dusk': return 'bg-gradient-to-b from-purple-500 via-pink-300 to-orange-200';
      case 'night': return 'bg-gradient-to-b from-slate-900 via-indigo-950 to-purple-900';
    }
  };

  const handleMove = useCallback((clientX: number, clientY: number) => {
    if (!canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const x = ((clientX - rect.left) / rect.width) * 100;
    const y = ((clientY - rect.top) / rect.height) * 100;

    if (selectedTool === 'magic') {
      // Create magic particles
      const particleTypes: MagicParticle['type'][] = ['star', 'sparkle', 'flower', 'heart', 'firefly'];
      const newParticle: MagicParticle = {
        id: Date.now() + Math.random(),
        x,
        y,
        vx: (Math.random() - 0.5) * 4,
        vy: -Math.random() * 3 - 1,
        size: 10 + Math.random() * 20,
        color: magicColors[Math.floor(Math.random() * magicColors.length)],
        life: 1,
        hue: Math.random() * 360,
        type: particleTypes[Math.floor(Math.random() * particleTypes.length)],
      };
      setParticles(p => [...p, newParticle]);
      setScore(s => s + 1);
    } else if (selectedTool === 'draw' || selectedTool === 'creature') {
      setCurrentPath(prev => [...prev, { x, y }]);
    }
  }, [selectedTool]);

  const handleStart = useCallback((clientX: number, clientY: number) => {
    setIsDrawing(true);
    setShowHint(false);
    handleMove(clientX, clientY);
  }, [handleMove]);

  const handleEnd = useCallback(() => {
    if (selectedTool === 'draw' && currentPath.length > 0) {
      setDrawings(d => [...d, {
        id: Date.now(),
        points: currentPath,
        color: selectedColor,
        size: brushSize,
      }]);
    } else if (selectedTool === 'creature' && currentPath.length > 0) {
      // Create creature from drawing
      const types: Creature['type'][] = ['butterfly', 'bird', 'fish', 'rabbit', 'cat'];
      const type = types[Math.floor(Math.random() * types.length)];
      const avgX = currentPath.reduce((a, b) => a + b.x, 0) / currentPath.length;
      const avgY = currentPath.reduce((a, b) => a + b.y, 0) / currentPath.length;
      
      const newCreature: Creature = {
        id: Date.now(),
        x: avgX,
        y: avgY,
        vx: (Math.random() - 0.5) * 2,
        vy: (Math.random() - 0.5) * 2,
        type,
        color: selectedColor,
        size: 30 + Math.random() * 20,
        life: 1,
      };
      setCreatures(c => [...c, newCreature]);
      setScore(s => s + 50);
    }
    setCurrentPath([]);
    setIsDrawing(false);
  }, [selectedTool, currentPath, selectedColor, brushSize]);

  const handleMouseDown = (e: React.MouseEvent) => handleStart(e.clientX, e.clientY);
  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDrawing) handleMove(e.clientX, e.clientY);
  };
  const handleTouchStart = (e: React.TouchEvent) => {
    const touch = e.touches[0];
    handleStart(touch.clientX, touch.clientY);
  };
  const handleTouchMove = (e: React.TouchEvent) => {
    if (isDrawing) {
      const touch = e.touches[0];
      handleMove(touch.clientX, touch.clientY);
    }
  };

  // Update particles
  useEffect(() => {
    const interval = setInterval(() => {
      setParticles(prev => 
        prev
          .map(p => ({
            ...p,
            x: p.x + p.vx * 0.3,
            y: p.y + p.vy * 0.3,
            vy: p.vy + 0.02,
            life: p.life - 0.008,
            size: p.size * 0.995,
          }))
          .filter(p => p.life > 0)
      );

      setCreatures(prev =>
        prev
          .map(c => ({
            ...c,
            x: c.x + c.vx,
            y: c.y + c.vy,
            vx: Math.max(-2, Math.min(2, c.vx + (Math.random() - 0.5) * 0.2)),
            vy: Math.max(-2, Math.min(2, c.vy + (Math.random() - 0.5) * 0.2)),
            life: c.life - 0.0005,
          }))
          .filter(c => c.life > 0 && c.x > -10 && c.x < 110 && c.y > -10 && c.y < 110)
      );
    }, 30);
    return () => clearInterval(interval);
  }, []);

  // Auto spawn creatures
  useEffect(() => {
    const interval = setInterval(() => {
      if (Date.now() - lastCreatureTime.current > 5000) {
        const types: Creature['type'][] = ['butterfly', 'bird', 'fish', 'rabbit', 'cat'];
        const type = types[Math.floor(Math.random() * types.length)];
        const newCreature: Creature = {
          id: Date.now(),
          x: Math.random() * 100,
          y: Math.random() * 100,
          vx: (Math.random() - 0.5) * 2,
          vy: (Math.random() - 0.5) * 2,
          type,
          color: magicColors[Math.floor(Math.random() * magicColors.length)],
          size: 25 + Math.random() * 15,
          life: 1,
        };
        setCreatures(c => [...c, newCreature]);
        lastCreatureTime.current = Date.now();
      }
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const getCreatureEmoji = (type: Creature['type']) => {
    const emojis = creaturesEmojis[type];
    return emojis[Math.floor(Math.random() * emojis.length)];
  };

  const getParticleEmoji = (type: MagicParticle['type']) => {
    switch (type) {
      case 'star': return '✨';
      case 'sparkle': return '💫';
      case 'flower': return '🌸';
      case 'heart': return '💖';
      case 'firefly': return '✨';
    }
  };

  const clearCanvas = () => {
    setParticles([]);
    setCreatures([]);
    setDrawings([]);
    setScore(0);
  };

  return (
    <div className={`min-h-screen ${getBackground()} transition-all duration-[10000ms] flex flex-col items-center justify-center p-2 overflow-hidden touch-none`}>
      {/* Stars (visible at night/dusk) */}
      {(timeOfDay === 'night' || timeOfDay === 'dusk') && (
        <div className="absolute inset-0 pointer-events-none">
          {stars.map((star, i) => (
            <div
              key={i}
              className="absolute bg-white rounded-full"
              style={{
                left: `${star.x}%`,
                top: `${star.y}%`,
                width: star.size,
                height: star.size,
                opacity: 0.3 + Math.sin(Date.now() * 0.002 + star.twinkle * 10) * 0.4,
              }}
            />
          ))}
        </div>
      )}

      {/* Sun/Moon */}
      {timeOfDay === 'day' && <div className="absolute top-4 right-8 text-6xl animate-pulse">☀️</div>}
      {timeOfDay === 'night' && <div className="absolute top-4 right-8 text-5xl">🌙</div>}
      {timeOfDay === 'dawn' && <div className="absolute top-4 right-8 text-5xl">🌅</div>}
      {timeOfDay === 'dusk' && <div className="absolute top-4 right-8 text-5xl">🌇</div>}

      {/* Score */}
      <div className="absolute top-2 left-2 z-10 bg-white/20 backdrop-blur-md rounded-full px-4 py-2">
        <span className="text-white font-bold">{score} ★</span>
      </div>

      {/* Time indicator */}
      <div className="absolute top-2 right-2 z-10 bg-white/20 backdrop-blur-md rounded-full px-3 py-1">
        <span className="text-white text-sm capitalize">{timeOfDay}</span>
      </div>

      {/* Tools */}
      <div className="relative z-10 mb-2 flex gap-2 flex-wrap justify-center">
        <button
          onClick={() => setSelectedTool('magic')}
          className={`p-3 rounded-full transition-all ${selectedTool === 'magic' ? 'bg-purple-500 scale-110' : 'bg-white/30'}`}
        >
          ✨
        </button>
        <button
          onClick={() => setSelectedTool('draw')}
          className={`p-3 rounded-full transition-all ${selectedTool === 'draw' ? 'bg-purple-500 scale-110' : 'bg-white/30'}`}
        >
          🖌️
        </button>
        <button
          onClick={() => setSelectedTool('creature')}
          className={`p-3 rounded-full transition-all ${selectedTool === 'creature' ? 'bg-purple-500 scale-110' : 'bg-white/30'}`}
        >
          🦋
        </button>
        <button
          onClick={clearCanvas}
          className="p-3 rounded-full bg-red-500/50 hover:bg-red-500 transition-all"
        >
          🗑️
        </button>
      </div>

      {/* Color picker */}
      <div className="relative z-10 mb-2 flex gap-1 flex-wrap justify-center max-w-md">
        {magicColors.map(color => (
          <button
            key={color}
            onClick={() => setSelectedColor(color)}
            className={`w-8 h-8 rounded-full transition-transform ${selectedColor === color ? 'scale-125 ring-2 ring-white' : ''}`}
            style={{ background: color }}
          />
        ))}
      </div>

      {/* Canvas */}
      <div
        ref={canvasRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleEnd}
        onMouseLeave={handleEnd}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleEnd}
        className="relative w-full max-w-2xl h-[60vh] cursor-crosshair rounded-3xl overflow-hidden"
      >
        {/* Hint */}
        {showHint && (
          <div className="absolute inset-0 flex items-center justify-center z-20 pointer-events-none">
            <div className="bg-white/80 backdrop-blur-md rounded-2xl p-6 text-center animate-pulse">
              <p className="text-4xl mb-2">👆</p>
              <p className="text-gray-700 font-medium">Ekranni cherting!</p>
              <p className="text-gray-500 text-sm">Sehrli joylar yarating</p>
            </div>
          </div>
        )}

        {/* Drawing paths */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none">
          {drawings.map(drawing => (
            <path
              key={drawing.id}
              d={`M ${drawing.points.map(p => `${p.x}% ${p.y}%`).join(' L ')}`}
              stroke={drawing.color}
              strokeWidth={drawing.size}
              strokeLinecap="round"
              strokeLinejoin="round"
              fill="none"
              opacity="0.7"
            />
          ))}
          {currentPath.length > 0 && (
            <path
              d={`M ${currentPath.map(p => `${p.x}% ${p.y}%`).join(' L ')}`}
              stroke={selectedColor}
              strokeWidth={brushSize}
              strokeLinecap="round"
              strokeLinejoin="round"
              fill="none"
            />
          )}
        </svg>

        {/* Creatures */}
        {creatures.map(creature => (
          <div
            key={creature.id}
            className="absolute transition-all duration-500"
            style={{
              left: `${creature.x}%`,
              top: `${creature.y}%`,
              transform: `translate(-50%, -50%) scale(${creature.size / 30})`,
              filter: `hue-rotate(${creature.color}20deg)`,
            }}
          >
            <span 
              className="text-3xl"
              style={{ 
                filter: `drop-shadow(0 0 8px ${creature.color})`,
                transform: `scaleX(${creature.vx > 0 ? 1 : -1})`,
              }}
            >
              {getCreatureEmoji(creature.type)}
            </span>
          </div>
        ))}

        {/* Magic particles */}
        {particles.map(particle => (
          <div
            key={particle.id}
            className="absolute pointer-events-none transition-all"
            style={{
              left: `${particle.x}%`,
              top: `${particle.y}%`,
              transform: 'translate(-50%, -50%)',
              fontSize: particle.size,
              opacity: particle.life,
              filter: `hue-rotate(${particle.hue}deg) drop-shadow(0 0 10px ${particle.color})`,
            }}
          >
            {getParticleEmoji(particle.type)}
          </div>
        ))}
      </div>

      {/* Instructions */}
      <div className="mt-2 text-white/70 text-sm text-center bg-black/20 backdrop-blur-md rounded-full px-4 py-2">
        <p>✨ = Sehrli effekt | 🖌️ = Chizish | 🦋 = Hayvonlar yaratish</p>
      </div>
    </div>
  );
}
